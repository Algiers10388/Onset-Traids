# Review summary (Nov 2026)

Reviewed in depth: `trade-agent/`, `flash-arb/` (contracts, Rust searcher, configs), `server.ts`, `server/flashArbRoutes.ts` (signer/deploy/agent parts), `src/middleware/auth.ts`.
Skimmed only (not line-by-line): `server/fiatRoutes.ts`, `server/exchangeRoutes.ts`, `server/walletRoutes.ts`, `server/sentimentRoutes.ts`, `src/App.tsx` and the large React components.
Nothing outside `trade-agent/` was compiled or run: no solc/forge/cargo/node_modules were available. Run `npm install`, `npm run compile:flash-arb`,
`forge test`, `cargo check && cargo test` before trusting any of it. See `trade-agent/CHANGES.md` and `flash-arb/CHANGES.md`.

Decisions that are yours:
1. Profit wallet: TOMLs say `0xc102...f15d`, the server and `.env.example` say `0x6560...ccb9`. Pick one, set `FLASH_ARB_PROFIT_WALLET`.
2. Rotate `FLASH_ARB_SIGNER_KEY` if the server was ever reachable beyond localhost.
3. Dashboard "flash-arb trades" from the server agent were ETH sweeps, not arbitrage; that path is now disabled.

## Second pass: server routes (this round)
- `/api/wallet/receive-address` returned HARD-CODED placeholder addresses (some are well-known Monero documentation addresses, others are
  filler like `Sal1J8k9vVj9Z9W8Z8Z8...`) and the UI showed them, with a QR code, as the deposit address. Funds sent there would be lost or go to a stranger.
  Now it only returns addresses you set in `.env` (`RECEIVE_ADDRESS_<COIN>`), else 404. The modal no longer keeps showing the previous coin's address after a failed fetch.
- `/api/exchange/execute-order` (real Kraken/Coinbase/Binance orders): Kraken sizing used `notional / 86000` (a hard-coded BTC price) for any asset;
  Kraken now requires `amount`. Optional `MAX_ORDER_NOTIONAL_USD` cap added. Known, not changed: `type` is ignored (always MARKET); no idempotency key.
- `/api/fiat/*` is an in-memory simulation (`fiatAccount` object, fake "tokenized" card ids, messages claiming FedWire/Plaid verification). It is not a payment processor.
  Raw card number + CVC still pass through it in JSON. Do not enter real card data. The success messages overstate what happens.
- `/api/exchange/wallet-transaction` mixes real Kraken orders with simulated ledger bookkeeping; not verified end to end.
- Not reviewed: `aiRoutes.ts`, `sentimentRoutes.ts`, `etherscanService.ts`, most of `src/`.

## Third pass: front end and live-trading safety
- **The app booted in real-money mode.** `tradingMode` defaulted to `LIVE_REAL_TRADING`, and the "switch to simulation" handler set it back to LIVE
  with the message "Simulation mode is disabled ... permanently engaged". With exchange keys on the server, every manual or bot trade was sent to a real exchange,
  and the confirmation modal only appeared when toggling *to* live, which was already the state. Now it defaults to `PAPER_SIMULATION` and the toggle works both ways.
- **Server kill switch:** `/api/exchange/execute-order` and BUY/SELL orders in `/api/exchange/wallet-transaction` return 403 unless `ENABLE_LIVE_TRADING=1` is set.
  The browser's mode is no longer the only thing between a click and a real order.
- Known, not changed: the UI books the position and cash locally first, then sends the real order fire-and-forget. A rejected real order leaves the app's
  position/cash out of sync with the exchange, and "FILLED" is logged when the exchange merely accepted the order (Kraken returns an order id, not a fill).
- Known, not changed: `/api/exchange/wallet-transaction` falls back to stale hard-coded prices (BTC 86450, ETH 2820, SOL 185) for balance math.
- Checked and fine: `firestore.rules` (owner-only, default deny), the five Firebase-authed routes use the token's uid (no IDOR), no `dangerouslySetInnerHTML`/`eval`
  in `src/`, no secrets in browser storage (only a contract address). Firebase web config in the repo is the public client kind.

## Fourth pass: live-only + fiat routes (supersedes the "defaults to PAPER_SIMULATION" note above)
- **Paper trading removed.** `TradingExecutionMode` is `'LIVE_REAL_TRADING'` only; the toggle, handlers and confirmation modal are gone;
  the bot portfolio starts at $0 (it was seeded with $5,000 of imaginary cash). `trade-agent`: no `PAPER_TRADING` exchange, no `--dry-run`/`--demo`,
  missing API keys now fail the order instead of silently simulating a fill. The server gate `ENABLE_LIVE_TRADING=1` stays: unset means orders are
  *refused*, not simulated.
- **`/api/fiat/*` rewritten.** Before: every deposit path credited balance with no processor behind it; 3DS accepted any 6-digit code (and returned the real OTP
  to the browser); 2FA accepted any 6 digits; `sync-bot-capital` let the client set the bot's capital; `FROM_BOT` minted money. Now: balance is credited only when Stripe
  confirms a PaymentIntent (net of fees, once per PI id, via response or signature-verified webhook); raw card data is rejected; real TOTP 2FA (`FIAT_TOTP_SECRET`);
  ledger persisted to `FIAT_LEDGER_PATH`; kill switch + per-order cap now actually enforced in `/api/exchange/*`; fake "FDIC/PCI/A+" claims removed.
  Bank/ACH, check deposit, withdrawals, bank/card linking and simulated 3DS return 501 (no processor exists for them).
- Tests: `trade-agent` 11/11 (`npm test`), fiat ledger 12/12 (`npx tsx --test server/fiatRoutes.test.ts`). Stripe was mocked; **nothing was run against real Stripe, a real exchange, or the browser UI**.
- Not done / yours: the card form in `LiveCurrencyAccountModal` still posts raw card numbers and must be rebuilt on Stripe Elements (it gets a clear 400 until then);
  the UI still books positions/cash locally before the exchange confirms (see third pass); `flashArbRoutes.ts`, `walletRoutes.ts`, `FlashArbBotDashboard.tsx` still contain
  simulation/demo wording that was not audited this pass.

## Fifth pass: live-only completion
- `flash-arb` searcher: removed `dry_run`, `--dry-run`, `--live` (live only; chains without a deployed contract are skipped, missing signer key/profit wallet aborts). Setup scripts now only build. **Not compiled (no cargo here): run `cargo check && cargo test`.**
- `server/exchangeRoutes.ts`: removed hard-coded prices (ETH 2820 x6, BTC 86450, SOL 185, BNB 620); live ticker price is used, and an order is refused (502) when none is available.
- `FlashArbBotDashboard.tsx`: typed two address variables that were inferred as `null`.
- Tests re-run: trade-agent 11/11, fiat ledger 12/12. Full `tsc` could not run (no node_modules offline); run `npm install && npm run lint`.

## Sixth pass: exchange-first order flow (`src/App.tsx`)
- Before: every buy/sell/arbitrage booked cash + positions locally, then fired the real order and ignored a rejection. `closePosition` also sent the real exit order from inside a `setPositions` updater, which React StrictMode runs twice (duplicate real orders), and the 500 ms bot loop could re-send the same exit every tick.
- Now: manual BUY, manual SELL, bot BUY, position exits and arbitrage send the order first and update cash/positions/orders only after the exchange accepts it. A rejected entry books nothing; a rejected exit keeps the position open and retries after 15 s; one exit and one entry order in flight at a time (`pendingCloseRef`, `pendingEntryRef`).
- Arbitrage: both legs are sent; profit is booked only if both are accepted. If only one leg goes through, it logs a "ONE-LEG ONLY, unhedged exposure" alert, records just that leg, and books no profit.
- Position monitor updater is pure again; exits are triggered from `positionsRef`. Daily-loss circuit breaker uses a ref instead of side effects inside an updater.
- Logs say "ACCEPTED", not "FILLED": the server returns an order id, not a fill price, so PnL and prices are quote-based estimates until you reconcile with the exchange.
- Verified only by type-check (no new errors; 3 older `{}` typing errors at App.tsx:406-408 remain and look like missing-React-types noise). Not run in a browser or against an exchange.

## Seventh pass: Stripe Elements card deposits
Pattern follows github.com/stripe-samples/accept-a-payment (deferred-intent Payment Element) and Stripe's docs.
- New `src/components/StripeCardDeposit.tsx`: loads the publishable key from `/api/fiat/config`, mounts `<PaymentElement>` (card only, no wallets/redirects), then `elements.submit()` -> `stripe.createPaymentMethod({ elements })` -> `POST /api/fiat/deposit/card` with the `pm_` id. On a 202 it runs real 3-D Secure with `stripe.handleNextAction()` and calls the new `POST /api/fiat/deposit/confirm`. Asks for the 6-digit 2FA code only when the server requires it. Shows a clear message if `STRIPE_SECRET_KEY` or `STRIPE_PUBLISHABLE_KEY` is missing.
- New `POST /api/fiat/deposit/confirm`: re-reads the PaymentIntent from Stripe (must carry `metadata.purpose=fiat_deposit`), credits net of Stripe fees only on `succeeded`, once per PaymentIntent id. Test added (fiat suite now 13/13).
- `LiveCurrencyAccountModal.tsx`: the three raw card-number forms (fund bot from card, debit-card deposit, saved-card selector) now use the Stripe component; the fund-bot form's generic submit is hidden for the card source. The two card-payout forms (link card, inline withdraw-to-card) were collecting card numbers for a feature the server cannot do (501), so they now show a notice. Dead handlers removed, and false claims ("AES-256 vault", "0% fee", "Zero Fraud Liability", "Visa Direct", "Zero Fee Guaranteed") removed from the card paths.
- `package.json`: added `@stripe/stripe-js` and `@stripe/react-stripe-js`. **Run `npm install` (bun.lock is not updated).** I could not check the latest versions offline; bump to current ones if you prefer.
- Not verified: no `node_modules`, so the new component was only parsed, not compiled against Stripe's types or run in a browser, and nothing ran against Stripe test mode. Do a test-mode deposit (card 4242 4242 4242 4242, then 4000 0025 0000 3155 for 3DS) before using live keys.
- Still leftover: other parts of `LiveCurrencyAccountModal.tsx` (bank link/ACH/check/withdraw tabs, card preview mockups) still render simulated-looking UI for features whose routes return 501.

## Eighth pass: Plaid Link + Stripe ACH bank deposits
Follows Plaid's Stripe guide (plaid.com/docs/auth/partnerships/stripe) and Stripe's "migrating from another processor" ACH flow (SetupIntent with skipped verification + mandate, then PaymentIntent). Requires Stripe to have enabled the skip-verification flow on your account.
- `server/plaidClient.ts` (new): Plaid REST client (sandbox/production), and a private store (`data/plaid-items.json`, mode 0600) for access tokens + Stripe ids. Access tokens and account numbers never reach the browser or the fiat ledger.
- `fiatRoutes.ts`: `POST /api/fiat/bank/link-token`, `POST /api/fiat/link-bank` (requires an explicit authorization flag; exchanges the token, reads ACH details for exactly one selected checking/savings account, rejects micro-deposit/unverified accounts, creates the Stripe SetupIntent, stores only masked details, de-duplicates the same account), `POST /api/fiat/deposit/bank` (ACH PaymentIntent; vault only, never straight to the bot; daily limit counts debits still processing; 2FA over $1,000), `DELETE /api/fiat/bank/:id` (removes the Plaid item and detaches the Stripe method).
- ACH lifecycle: a submitted debit shows as PROCESSING and adds to `pendingBalance`; the signed webhook credits the ledger on `payment_intent.succeeded` (that same row becomes COMPLETED, net of the Stripe fee, once only); `payment_intent.payment_failed` releases the hold and marks the row FAILED. The existing dispute/return freeze still applies. Added `FAILED` to `FiatTransaction.status`.
- UI: new `src/components/PlaidBankDeposit.tsx` (react-plaid-link): name + ACH authorization, Plaid Link, linked-bank list with unlink, deposit with 2FA prompt. Replaces the manual routing/account number forms in the Bank tab, Add Bank tab and fund-bot bank source (bank can't fund the bot directly: it points to the Bank tab). The withdraw tab's raw routing/account inputs are gone too. Removed `linkBankAccount`/`depositViaBank` from `fiatApi.ts`.
- `/api/fiat/config` now reports `rails.bank` (true only with Plaid + Stripe configured) and the Plaid env. `.env.example`: `PLAID_ENV=sandbox` by default, plus `PLAID_REDIRECT_URI`, `PLAID_STORE_PATH`.
- Tests: fiat suite 19/19 (Plaid and Stripe mocked): authorization required, secrets never in responses or ledger file, micro-deposit refusal, duplicate link, ACH pending then credited once by signed webhook, failure releases hold, unlink cleanup, 503 when unconfigured.
- Not verified: no `node_modules` or network here, so nothing ran against Plaid sandbox or Stripe test mode and the React component was only syntax-checked. `react-plaid-link@^4.0.1` was pinned from memory. Specific risks to check in test mode: Stripe accepting the `mandate` id on the PaymentIntent, and `offline` mandate type matching what Stripe approved for your account.
- Not built: Plaid OAuth return handling (many large banks sign in via OAuth in production; needs `PLAID_REDIRECT_URI` plus re-opening Link on the redirect page), micro-deposit verification, bank withdrawals/payouts (no payout provider), Plaid webhooks (item errors, re-auth).

## Ninth pass: PayPal withdrawals (Payouts API)
Per developer.paypal.com/api/payouts: OAuth client-credentials, `POST /v1/payments/payouts` (EMAIL recipient, `PayPal-Request-Id` + `sender_batch_id` for idempotency), `GET /v1/payments/payouts/{id}` for status. Cash App was not added: its payout API is early-access/partner-only and `$Cashtag` sends are not available through public APIs.
- `server/paypalClient.ts` (new): REST client with token cache and 20 s timeout. Errors are flagged `ambiguous` when the outcome is unknown (network failure/timeout/5xx).
- `POST /api/fiat/withdraw/paypal`: only pre-registered emails (`PAYPAL_PAYOUT_RECIPIENTS`, referenced by index, never typed); always needs a fresh TOTP code; daily limit (`FIAT_DAILY_WITHDRAWAL_LIMIT_USD`, default $1,000); blocked by the emergency freeze; needs an idempotency key. The amount is reserved on the ledger and saved to disk BEFORE PayPal is called. Same key again returns the original result and never pays twice.
- Outcomes: PayPal refuses -> refunded immediately; PayPal accepts -> PROCESSING; unknown outcome -> stays reserved (never auto-refunded, to avoid paying twice) and can be resolved by hand with 2FA (`/resolve`, only for rows with no PayPal payout id, once).
- Status always comes from PayPal: `POST /api/fiat/withdraw/paypal/reconcile` and the optional `POST /api/fiat/paypal/webhook` (open path in `server.ts`; its body is never trusted, it only triggers a re-read from PayPal). SUCCESS -> COMPLETED with the PayPal fee recorded; FAILED/BLOCKED/RETURNED/REFUNDED/REVERSED/CANCELED/DENIED -> refunded exactly once. UNCLAIMED stays processing until PayPal returns it.
- UI: new `PayPalWithdraw.tsx` replaces the old multi-rail withdraw tab (bank/FedNow/wire/card screens that could never work). `FiatTransaction` gained `WITHDRAW_TO_PAYPAL`, rail `PAYPAL_PAYOUT`, and `externalId`.
- Tests: fiat suite 26/26 (PayPal mocked): input refusals touch nothing, reservation + exact request body, duplicate key, PENDING -> COMPLETED with fee, returned payout refunded once, definitive refusal refunded, unknown outcome + 2FA-gated one-time resolve, forged webhook ignored, 503 when unconfigured.
- Not verified against PayPal: no network here. Test in PayPal sandbox first. PayPal Payouts must be enabled on the Business account and funded from your PayPal balance (Stripe cannot pay out to PayPal), and PayPal may charge a payout fee on top of the amount. Late reversals after a payout shows SUCCESS are not tracked. Ledger-to-PayPal funding is not automated: you must keep the PayPal balance topped up.

## Merge note (banking + live-only trade-agent)
- Base = the banking tree (fiat/Stripe/Plaid/PayPal, exchange-first order flow, live-only searcher with fail-fast key/wallet checks).
- `trade-agent/` is the version that sizes from the real exchange balance (`fetchQuoteBalance`), floors orders to LOT_SIZE, nets base-asset commission and reads OKX fills back.
  The banking tree's copy still used an invented `initialTreasuryUsd: 10000` and kept demo-feed code, so it was replaced.

## Configuration verification (merged tree)
Checked by script and by running the code offline (no network, no node_modules, no cargo/forge):
- Syntax of every `.ts`/`.tsx` file: 0 errors. `bash -n` on all `.sh`: ok. All JSON/tsconfig files parse.
- Every bare import in `server*/src/scripts` is declared in `package.json` (incl. Stripe, Plaid, PayPal deps). Run `npm install` first (bun.lock is stale).
- Env vars: all Stripe/Plaid/PayPal/FIAT_* names used by the code are documented. Added the ones that were missing (`OKX_*`, `APP_PORT`, `HOST`, `SQL_*`, `FLASH_ARB_OWNER_ADDRESS`, `RUST_LOG`, `CONFIRM_DEPLOY`).
- Searcher TOMLs: every required field of `ChainConfig`/`RiskConfig` is present and every `[dexes.*]` key matches `DexConfig`. (Checked against the Rust structs by reading them; not by compiling.)
- Tests: trade-agent 11/11, fiat/Stripe/Plaid/PayPal ledger 26/26 (providers mocked).
- trade-agent CLI exercised: missing keys, leverage != 1, OKX without passphrase, unsupported exchange, bad strategy, negative capital all exit with a clear error;
  `--dry-run`/`--demo`/`--paper` are now rejected (before this they were silently ignored and the agent started LIVE).
Open items that are config, not code:
1. **Profit wallet: RESOLVED to MetaMask `0x65602EB9e09B07002872E074004400d37e27CCB9` (0x6560...ccb9) in the last round; the text below is history.** (Was: `0xc102...f15d` is what the TOMLs and the UI's "Cake Wallet" screens use; `0x6560...ccb9` is what `server/flashArbRoutes.ts` and `.env.example` use,
   and the server *overwrites* 0xc102 with 0x6560 at startup. The TOML `[beneficiary]`/`[signer]` tables are not read by any code (dead config), so the searcher uses only the `FLASH_ARB_PROFIT_WALLET`
   env var, which is mandatory with no default; `flash-arb/searcher/run-live.sh` now supplies the MetaMask default.)
2. `.env.example` has `PLAID_ENV=sandbox` and Stripe keys unset: card/bank deposits stay disabled until you add keys (`/api/fiat/config` reports which rails are on). Start in test mode.
3. Not verifiable offline: real Stripe/Plaid/PayPal calls, Binance/OKX order placement, `cargo check`, `forge test`, `npm run build`, browser behaviour of the new App.tsx order flow.

## npm install fix
`npm install` failed with ERESOLVE: root `esbuild@^0.25.0` conflicted with Vite 8's optional peer `esbuild ^0.27 || ^0.28`. Root `esbuild` is now `^0.28.0`
(`drizzle-kit` keeps its own nested 0.25, which is fine because that is a normal dependency, not a peer). Fallback: `npm install --legacy-peer-deps`.

## Eighth pass: merge of v9 line + `main` (no fallbacks / no fabricated data)
- Base: the v9 line (live-only, Stripe/Plaid/PayPal). From `main`: `server/arbSizing.ts` (+ test), `server/marketData.test.ts`, `MarketDataUnavailableError` (503).
- Removed everywhere: hard-coded prices (ETH 2675/2850, BTC 76905), synthetic candles/quotes, canned AI answers and model fallback, fabricated Etherscan trade patterns/receipts,
  seeded news feed (sentiment now = CryptoCompare headlines + alternative.me Fear & Greed, scored by Gemini), default wallet addresses (env only).
- Etherscan service reads only Etherscan V2 (`ETHERSCAN_API_KEY`); no public-RPC rotation.
- Flash-arb pool prices/depth are on-chain reads only; sizing uses the measured-depth model. Profit wallet: `0x65602EB9e09B07002872E074004400d37e27CCB9` (the `c102...` address is the Cake wallet, not a profit wallet).
- Tests run: arbSizing 5/5, marketData 4/4, fiat 26/26 (all offline, network mocked). The browser UI and live exchanges/RPC were NOT exercised.

## Contract compile fix + address hygiene
- `solc` rejected `test/FlashArb.t.sol:21` (Aave provider `...7ECBAB3CDb`: wrong EIP-55 checksum; correct `...7ECBaB3CDb`). Fixed.
- A full EIP-55 scan found 59 more wrong-case address literals in TOML/TS/RS files (18 distinct). Solidity ignores those files but strict JS libraries throw on them.
  All were rewritten to the correct checksum case; hex digits are unchanged. This does NOT prove the addresses are right: run `npm run verify:addresses -- arbitrum`
  (also base, optimism) from a machine with internet. It calls `eth_getCode` for every configured contract and checks the chain id.
- MetaMask profit wallet in checksum form: `0x65602EB9e09B07002872E074004400d37e27CCB9` (should match what MetaMask shows).
- Runner scripts: the offline mock tests (`FlashArbOptimized.t.sol`) now run without a network. Fork tests are opt-in (`RUN_FORK_TESTS=1`) and use the latest block;
  the old pinned block 225000000 needs an archive node and failed on public RPCs. Stale "Dry-Run Mode" labels removed.

## Logic verification pass (offline)
Verified by running code, not by reading:
- Indicators (EMA, RSI, MACD line/signal/histogram incl. index alignment, Bollinger, ATR) match independent numpy implementations to 1e-9 on 300 random candles.
- Searcher opportunity math (`optimal_input` / `cycle_output`): checked against brute force on 3,000 random pool pairs (1,496 profitable, 1,504 correctly "no trade"); closed form is optimal within grid resolution; fees larger than the spread give no trade.
- Calldata: Rust `encode_execute_call` argument order matches `executeOptimizedArbitrage(address,address,uint256,address,address,uint24,uint24,uint8,uint256,address)`; selector of `executeDirectFlashArb(address)` is 0x7804d9ac as the server expects.
- Access guard (`server/accessGuard.ts`, 8 tests): local passes; remote, proxied (X-Forwarded-*, K_SERVICE) and wrong/empty/non-ASCII tokens are refused; only health, the two webhooks and the Firebase-authed routes are open. Fixed a latent crash: token compared by string length instead of byte length.
- trade-agent 11/11, fiat/Stripe/Plaid/PayPal ledger 26/26, guard 8/8. `scripts/verify-addresses.cjs` exercised against a fake RPC (detects missing contract, wrong chain id, missing function selector).
- Dashboard text said profits go to `0xc102...f15d` and silently ignored a saved 0xc102 address on reload; both fixed (MetaMask is the default; a wallet you set is kept).
NOT verifiable here: `cargo check/test`, `forge build/test`, `npm run build`, the browser UI, any real exchange/Stripe/Plaid/PayPal/RPC call.
Findings that need your attention:
1. Only Arbitrum has more than one supported venue (Uniswap V3 + Camelot V2 + Sushi V2). On Base and Optimism the second DEX (Aerodrome/Velodrome) is `Unsupported`, so the searcher can only compare Uniswap V3 fee tiers against each other.
2. Camelot's router may not expose plain `swapExactTokensForTokens` (it is documented with a referrer variant). Run `npm run verify:addresses -- arbitrum`: it flags a missing selector. If flagged, Camelot legs will revert in simulation and never be sent (safe, but no Camelot trades).
3. RSI of a perfectly flat series returns 100 (no losses), which blocks entries; harmless in practice.

## Ninth pass: merge of the uploaded v12 (hardening) with the fake-data removal
- Three-way merge (base v9). From the uploaded v12: `server/accessGuard.ts` (+8 tests), `scripts/verify-addresses.cjs`, FlashArb.t.sol checksum fix, runner scripts, esbuild fix, dashboard `0xc102` fix.
- Every 0x+40-hex literal in the tree was re-normalised to EIP-55 with a keccak-256 implementation checked against 6 canonical mainnet addresses. This corrected addresses the earlier scan had left
  (e.g. in `etherscanService.ts`, `walletRoutes.ts`, `flashArbConfig.ts`). Casing only: no address changed. `public/flash-arb.zip` was rebuilt afterwards.
- Profit wallet everywhere: `0x65602EB9e09B07002872E074004400d37e27CCB9`.
- Tests (offline): accessGuard 8/8, arbSizing 5/5, marketData 4/4, fiat 26/26. Not run: browser UI, cargo, forge, npm build, any live RPC/exchange.
- Still to run on your machine: `npm run verify:addresses -- arbitrum` (also base, optimism): it checks the pool/token addresses I carried over exist on-chain.
