# Quantitative Crypto Trading Suite & Multi-Chain Flash Loan Arbitrage Engine

This package contains two complete, live-execution quantitative systems:

1. `trade-agent/`:
   - Autonomous CEX Spot Trading Agent with MACD (12, 26, 9), RSI (14), Bollinger Bands (20, 2), Regular Divergence, and Confluence Scoring (0-100%).
   - Multi-Exchange Live Execution: Binance, OKX, Coinbase, Bybit, Kraken.
   - Dynamic Risk Management: Daily loss circuit breakers, fractional Kelly position sizing, Take-Profit, Stop-Loss, and peak-tracking Trailing Stops.
   - One-click runners: `run_termux.sh` (Android), `run_wsl.sh` (Linux), `run_powershell.ps1` (Windows).

2. `flash-arb/`:
   - Smart Contracts (`contracts/`): Cancun EIP-1153 `FlashArbOptimized.sol` (Balancer V2 0% fee & Aave V3 0.05% fallback; Route Types 1-4 across UniV3, PancakeV3, SushiV3, QuickSwap/Camelot V3, and V2).
   - Searchers (`searcher/` & Node server `server/flashArbRoutes.ts`): Multicall3 live pool polling across 10 chains (Ethereum, Polygon, BSC, Arbitrum, Base, Optimism, Avalanche, Linea, Scroll, ApeChain), closed-form S* depth sizing, zero-gas `eth_call` pre-flight verification, continuous auto-trading, and automatic Profit Vault (`0xD5503C876a5DFeE057727cfacb6a59E8C7554f5b`) sweeping.
   - Cross-platform Foundry & Cargo runners for Termux, WSL, and Windows.
