# Quantitative Crypto Trading Suite & Flash Loan Arbitrage Engine

This package contains two complete, production-ready quantitative systems:

1. `trade-agent/`:
   - Autonomous Crypto Trading Agent with MACD (12, 26, 9), RSI (14), Bollinger Bands (20, 2), Regular Divergence, and Confluence Scoring (0-100%).
   - Multi-Exchange Execution: Paper Trading / Dry-Run (zero keys needed) & Authenticated Live Trading on Binance, OKX, Coinbase, Bybit, Kraken.
   - Dynamic Risk Management: Daily loss circuit breakers, fractional Kelly position sizing, Take-Profit, Stop-Loss, and peak-tracking Trailing Stops.
   - One-click runners: `run_termux.sh` (Android), `run_wsl.sh` (Linux), `run_powershell.ps1` (Windows).

2. `flash-arb/`:
   - Smart Contracts (`contracts/`): Atomic flash loan arbitrage executor (Aave V3, Uniswap V3, Curve, Camelot) written in Solidity (^0.8.20).
   - Rust Searcher (`searcher/`): Low-latency WebSocket pool monitor, closed-form V2 & ternary V3 loan sizer, revm state simulator, and private relay tx builder.
   - Cross-platform Foundry runners for Termux, WSL, and Windows.
